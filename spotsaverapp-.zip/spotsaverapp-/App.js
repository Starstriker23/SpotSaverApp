import { StyleSheet, Text, View, Button, Alert, Modal, TextInput } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useState, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect } from 'react';

export default function App() {

  //State variables
  const [userLocation, setUserLocation] = useState(null);
  const [showAddPinModal, setShowAddPinModal] = useState(false);
  const [pinAddress, setPinAddress] = useState("");
  const [pinName, setPinName] = useState("");
  const [pinDescription, setPinDescription] = useState("");
  const [pins, setPins] = useState([]);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showMyPinsModal, setShowMyPinsModal] = useState(false);
  const mapRef = useRef(null);

  //Saves pins to device whenever they change
  useEffect(() => {
    AsyncStorage.setItem("savedPins", JSON.stringify(pins));
  }, [pins]);

  //Loads saved pins when the app starts
  useEffect(() => {
    async function loadPins() {
      const storedPins = await AsyncStorage.getItem("savedPins");
      if (storedPins) {
        setPins(JSON.parse(storedPins));
      }
    }
    loadPins();
  }, []);

  //Gets the user current location and updates the map
  async function handleShowMe() {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      alert('Permission to access location was denied');
      return;
    }

    let location = await Location.getCurrentPositionAsync({});
    const coords = {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    };

    setUserLocation(coords);
  }

  //Opens an alert with option the add or delete pins
  function handleEditPins() {
    Alert.alert(
      "Edit Pins",
      "What would you like to do?",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Delete Pin", onPress: () => setShowDeleteModal(true) },
        { text: "Add Pin (Use Show Me 1st)", onPress: () => setShowAddPinModal(true) }
      ]
    );
  }

  //Moves the map camera to the user selected pin
  function goToPin(pin) {
    mapRef.current.animateToRegion(
      {
        latitude: pin.latitude,
        longitude: pin.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      },
      800 //animation duration in ms
    );

    setShowMyPinsModal(false);
  }

  //Deletes a pin by ID
  function handleDeletePin(id) {
    setPins(pins.filter(pin => pin.id !== id));
    setShowDeleteModal(false);
  }

  //Adds a new pin after geocoding the address
  async function handleSubmitPin() {
    if (!pinAddress || !pinName) {
      alert("Address and name are required");
      return;
    }

    try {
      console.log("Geocoding:", pinAddress);

      //Geocdes with Hamilton context first
      let geocode = await Location.geocodeAsync(`${pinAddress}, Hamilton, Ontario, Canada`);

      //If it's not in Hamilton, it uses raw input 
      if (geocode.length === 0) {
        geocode = await Location.geocodeAsync(pinAddress);
      }

      console.log("Result:", geocode);

      if (geocode.length === 0) {
        alert("Could not find that address.");
        return;
      }

      const { latitude, longitude } = geocode[0];

      //Creates new pin object
      const newPin = {
        id: Date.now(),
        latitude,
        longitude,
        name: pinName,
        address: pinAddress, 
        description: pinDescription
      };

      //Adds all pins to array
      setPins([...pins, newPin]);

      //Resets modal and inputs
      setShowAddPinModal(false);
      setPinAddress("");
      setPinName("");
      setPinDescription("");

    } catch (error) {
      console.log("Geocode error:", error);
      alert("There was an error looking up that address.");
    }
  }

  return (
    <View style={styles.container}>
      
      //The app title and intro text
      <Text style={styles.title}>The Hamilton Spot Saver</Text>
      <Text style={styles.paragraph}>
        Welcome to our unique city-exploring app! 
        {'\n'}Here, you can save all your favorite Hamilton locations with just a couple clicks. 
        {'\n'}Happy Exploring!  :)
      </Text>
      
      //The top buttons
      <View style={styles.buttonRow}>
        <View style={styles.buttonWrapper}>
          <Button title="My Pins" onPress={() => setShowMyPinsModal(true)} />
        </View>
        <View style={styles.buttonWrapper}>
          <Button title="Edit Pins" onPress={handleEditPins} />
        </View>
        <View style={styles.buttonWrapper}>
          <Button title="Show Me" onPress={handleShowMe} />
        </View>
      </View>

      //The map
      <MapView 
        ref={mapRef}
        style={styles.map}
        initialRegion={{
          latitude: 43.2557,
          longitude: -79.8711,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05
        }}
        showsUserLocation={true}
      >

        //The user's current location marker
        {userLocation && (
          <Marker
            coordinate={userLocation}
            title="You are here"
            pinColor="teal"
          />
        )}

        //Other saved pins
        {pins.map(pin => (
          <Marker
            key={pin.id}
            coordinate={{ latitude: pin.latitude, longitude: pin.longitude }}
            title={pin.name}
            description={pin.description ? `${pin.address}\n${pin.description}` : pin.address}
          />
        ))}
      </MapView>

      //Add pin modal
      <Modal visible={showAddPinModal} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Add a New Pin</Text>

            <TextInput
              placeholder="Address"
              style={styles.input}
              value={pinAddress}
              onChangeText={setPinAddress}
            />

            <TextInput
              placeholder="Name"
              style={styles.input}
              value={pinName}
              onChangeText={setPinName}
            />

            <Button title="Submit" onPress={handleSubmitPin} />
            <Button title="Cancel" onPress={() => setShowAddPinModal(false)} />
          </View>
        </View>
      </Modal>

      //Delet pin modal
      <Modal visible={showDeleteModal} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Delete a Pin</Text>

            {pins.length === 0 ? (
              <Text>No pins to delete.</Text>
            ) : (
              pins.map(pin => (
                <Button
                  key={pin.id}
                  title={`Delete: ${pin.name}`}
                  onPress={() => handleDeletePin(pin.id)}
                />
              ))
            )}

            <Button title="Cancel" onPress={() => setShowDeleteModal(false)} />
          </View>
        </View>
      </Modal>

      //My pins modal
      <Modal visible={showMyPinsModal} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>My Saved Pins</Text>

            {pins.length === 0 ? (
              <Text>No saved pins yet.</Text>
            ) : (
              pins.map(pin => (
                <Button
                  key={pin.id}
                  title={pin.name}
                  onPress={() => goToPin(pin)}
                />
              ))
            )}

            <Button title="Close" onPress={() => setShowMyPinsModal(false)} />
          </View>
        </View>
      </Modal>
    </View>  
  );       
}

//General Styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: "#4169E1",
    padding: 20,
    marginTop: 40,
    width: "100%"
  },

  map: { 
    flex: 2 
  },

  title: { 
    fontSize: 32,
    fontWeight: "900",
    marginBottom: 20,
    color: "#FFD700",             
    textShadowColor: "#000",
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 3,
    textAlign: "center",
    backgroundColor: "#4169E1"
  },

  buttonWrapper: {
    backgroundColor: "#4169E1",
    borderRadius: 10,
    paddingVertical: 8,
    flex: 1,
    marginHorizontal: 5,
    overflow: "hidden"
  },

  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "103%",
    marginVertical: 10,
    alignSelf: "center"
  },

  paragraph: {
    textAlign: "center",
    color: "#FFD700",
    fontWeight: "600"             
  },

  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)"
  },

  modalBox: {
    width: "80%",
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10
  },

  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    marginVertical: 5,
    borderRadius: 5
  }
});